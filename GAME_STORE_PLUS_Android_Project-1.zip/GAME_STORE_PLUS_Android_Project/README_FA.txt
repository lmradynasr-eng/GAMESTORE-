GAME STORE + — پروژه اندروید

این فایل ZIP یک پروژه Android Studio است، نه APK آماده نصب.
برای ساخت APK:
1) Android Studio را روی ویندوز نصب کن.
2) ZIP را استخراج کن.
3) در Android Studio گزینه Open را بزن و پوشه GAME_STORE_PLUS_Android_Project را انتخاب کن.
4) صبر کن Gradle Sync کامل شود و اگر SDK 35 خواست، از SDK Manager نصبش کن.
5) از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) را بزن.
6) پس از پایان، روی Locate بزن. معمولاً APK اینجاست:
   app/build/outputs/apk/debug/app-debug.apk
7) فایل APK را به گوشی منتقل و نصب کن. ممکن است اندروید اجازه نصب از منبع موردنظر را بخواهد.

نکته‌ها:
- برنامه یک WebView است که فایل HTML فعلی را داخل اپ باز می‌کند.
- تصاویر با آدرس اینترنتی برای نمایش به اینترنت نیاز دارند.
- اطلاعاتی که سایت با localStorage ذخیره می‌کند در فضای WebView این برنامه ذخیره می‌شود؛ داده‌های مرورگر عادی به اپ منتقل نمی‌شوند.
- این پروژه هنوز در این محیط با Android SDK ساخته یا روی گوشی آزمایش نشده است.
